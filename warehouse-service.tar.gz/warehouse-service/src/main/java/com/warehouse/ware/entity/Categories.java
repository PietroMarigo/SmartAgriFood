package com.warehouse.ware.entity;

public enum Categories {
  FRUTTA,
  VERDURA,
  ALTRI;
}
